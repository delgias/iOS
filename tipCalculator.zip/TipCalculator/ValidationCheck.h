//
//  ValidationCheck.h
//  tipCalculator
//
//  Created by Delgias on 9/30/13.
//  Copyright (c) 2013 Delgias All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ValidationCheck : NSObject

+ (BOOL) isNumericC:(NSString*) s;

@end
