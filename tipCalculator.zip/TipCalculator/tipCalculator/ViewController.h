//
//  ViewController.h
//  tipCalculator
//
//  Created by Delgias on 9/26/13.
//  Copyright (c) 2013 Delgias All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    IBOutlet UILabel *label;
}

@property (nonatomic, retain) IBOutlet UITextField *txtName;
@property (nonatomic, retain) IBOutlet UITextField *totalBill;


-(IBAction)btnClicked:(id)sender;

-(IBAction)btn15Clicked:(id)sender;

-(IBAction)btn20Clicked:(id)sender;

-(IBAction)moveKeyboard:(id)sender;

@end
