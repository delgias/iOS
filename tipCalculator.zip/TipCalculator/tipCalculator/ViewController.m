//
//  ViewController.m
//  tipCalculator
//
//  Created by Delgias on 9/26/13.
//  Copyright (c) 2013 Delgias All rights reserved.
//

#import "ViewController.h"
#import "ValidationCheck.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize txtName = _txtName;
@synthesize totalBill = _totalBill;


-(IBAction)btnClicked:(id)sender
{
    NSString *uInput = [[NSString alloc] initWithString:_txtName.text];
    
    NSNumberFormatter *format = [NSNumberFormatter new];
    [format setNumberStyle:NSNumberFormatterCurrencyStyle];
    
    if ([ValidationCheck isNumericC:(uInput)])
    {
        NSDecimalNumber *twentyPercent = [NSDecimalNumber decimalNumberWithString:@"1.1"];
        NSDecimalNumber *twenty = [NSDecimalNumber decimalNumberWithString:@"0.1"];
        NSDecimalNumber * decimal = [NSDecimalNumber decimalNumberWithString:_txtName.text];
        
        NSDecimalNumber* totalBillValue = [decimal decimalNumberByMultiplyingBy:twentyPercent];
        NSDecimalNumber* tip = [decimal decimalNumberByMultiplyingBy:twenty];
        
        label.text = [NSString stringWithFormat:@"%@ tip", [format stringFromNumber:tip]];
        
        _totalBill.text = [format stringFromNumber:totalBillValue];
        
    }
    else
    {
        NSString *str =
        [[NSString alloc] initWithFormat:@"Enter a number"];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error in Input" message:str delegate:self cancelButtonTitle:@"Done" otherButtonTitles:nil];
        
        [alert show];
        [alert release];
        [str release];
    }
    
    [uInput release];
    
    [_totalBill resignFirstResponder];
    [_txtName resignFirstResponder];
    
    
}

-(IBAction)btn15Clicked:(id)sender
{
    NSString *uInput = [[NSString alloc] initWithString:_txtName.text];
    
    NSNumberFormatter *format = [NSNumberFormatter new];
    [format setNumberStyle:NSNumberFormatterCurrencyStyle];
    
    
    if ([ValidationCheck isNumericC:(uInput)])
    {
        NSDecimalNumber *twentyPercent = [NSDecimalNumber decimalNumberWithString:@"1.15"];
        NSDecimalNumber *twenty = [NSDecimalNumber decimalNumberWithString:@"0.15"];
        NSDecimalNumber * decimal = [NSDecimalNumber decimalNumberWithString:_txtName.text];
        
        NSDecimalNumber* totalBillValue = [decimal decimalNumberByMultiplyingBy:twentyPercent];
        NSDecimalNumber* tip = [decimal decimalNumberByMultiplyingBy:twenty];
        
        label.text = [NSString stringWithFormat:@"%@ tip", [format stringFromNumber:tip]];
        
        _totalBill.text = [format stringFromNumber:totalBillValue];
    }
    else
    {
        NSString *str =
        [[NSString alloc] initWithFormat:@"Enter a number"];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error in Input" message:str delegate:self cancelButtonTitle:@"Done" otherButtonTitles:nil];
        
        [alert show];
        [alert release];
        [str release];
    }
    
    [uInput release];
    [_totalBill resignFirstResponder];
    [_txtName resignFirstResponder];
    
}

-(IBAction)btn20Clicked:(id)sender
{
    
    NSString *uInput = [[NSString alloc] initWithString:_txtName.text];
    
    if ([ValidationCheck isNumericC:(uInput)])
    {
        NSNumberFormatter *format = [NSNumberFormatter new];
        [format setNumberStyle:NSNumberFormatterCurrencyStyle];
        
        NSDecimalNumber *twentyPercent = [NSDecimalNumber decimalNumberWithString:@"1.2"];
        NSDecimalNumber *twenty = [NSDecimalNumber decimalNumberWithString:@"0.2"];
        NSDecimalNumber * decimal = [NSDecimalNumber decimalNumberWithString:_txtName.text];
        
        NSDecimalNumber* totalBillValue = [decimal decimalNumberByMultiplyingBy:twentyPercent];
        NSDecimalNumber* tip = [decimal decimalNumberByMultiplyingBy:twenty];
        
        label.text = [NSString stringWithFormat:@"%@ tip", [format stringFromNumber:tip]];
        
        _totalBill.text = [format stringFromNumber:totalBillValue];
        
    }
    else
    {
        NSString *str =
        [[NSString alloc] initWithFormat:@"Enter a number"];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error in Input" message:str delegate:self cancelButtonTitle:@"Done" otherButtonTitles:nil];
        
        [alert show];
        [alert release];
        [str release];
    }
    
    [uInput release];
    [_totalBill resignFirstResponder];
    [_txtName resignFirstResponder];
    
}


-(IBAction)moveKeyboard:(id)sender
{
    [_totalBill resignFirstResponder];
    [_txtName resignFirstResponder];
    
}


-(void) dealloc
{
    [_txtName release];
    [_totalBill release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
