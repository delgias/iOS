//
//  main.m
//  tipCalculator
//
//  Created by Delgias on 9/26/13.
//  Copyright (c) 2013 Delgias All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
