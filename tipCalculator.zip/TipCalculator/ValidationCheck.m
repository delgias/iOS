//
//  ValidationCheck.m
//  tipCalculator
//
//  Created by Delgias on 9/30/13.
//  Copyright (c) 2013 Delgias All rights reserved.
//

#import "ValidationCheck.h"

@implementation ValidationCheck


+ (BOOL) isNumericC:(NSString*) s { if ( [s length] == 0 )
{
    return false; }
    NSScanner *sc = [NSScanner scannerWithString: s]; if ( [sc scanFloat:NULL] )
    {
        return [sc isAtEnd]; }
    return NO; }


@end
