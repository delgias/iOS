//
//  ContactModel.h
//  DatabaseAssignment
//
//  Created by Delgias on 11/13/13.
//  Copyright (c) 2013 Delgias. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ContactModel : NSObject

{
    
}

@property (nonatomic, retain) NSString* firstName;
@property (nonatomic, retain) NSString* lastName;
@property (nonatomic, retain) NSString* email;
@property (nonatomic, retain) NSString* phone;
@property (nonatomic, assign) int ID;

-(void) LogContact;

@end