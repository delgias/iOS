//
//  ViewController.m
//  DatabaseAssignment
//
//  Created by Delgias on 11/13/13.
//  Copyright (c) 2013 Delgias. All rights reserved.
//

#import "ViewController.h"
#import "addButtonViewController.h"
#import "Storage.h"
#import "ContactModel.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize tView =_tView;

-(void) tableView:(UITableView *) tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row >= 0)
    {
       
        addButtonViewController *vc;
        vc = [[[addButtonViewController alloc ] initWithNibName:@"addButtonViewController" bundle:nil] autorelease];
        vc.indexFromVC = indexPath.row;
        vc.flag = true;
     //   vc.updateDelegate = self;
        vc.addClicked =false;
        
        vc.updateView = self;
        
        
        [self.navigationController pushViewController:vc animated:YES];
    }
    
}

-(void) tableChange;
{
    [self.tView reloadData];
}


-(void) addButtonClick
{
    addButtonViewController *vc;
    vc = [[[addButtonViewController alloc] initWithNibName:@"addButtonViewController" bundle:Nil] autorelease];
    vc.updateView = self;
   vc.addClicked = true;
    vc.flag = false;
    [self.navigationController pushViewController:vc animated:YES];
}

-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[Storage shared].contactArray count];
}

-(UITableViewCell *) tableView:(UITableView *) tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier: cellIdentifier] autorelease];
    }
    
    ContactModel* cm = [[Storage shared].contactArray objectAtIndex:indexPath.row];
    NSString* s = [NSString stringWithFormat:@"%@, %@", cm.lastName, cm.firstName];
    cell.textLabel.text = s;
    
    
    return cell;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    [super viewDidLoad];
    
    UIBarButtonItem *addButton = [[UIBarButtonItem alloc]
                                  initWithTitle:@"Add" style:UIBarButtonItemStylePlain target:self
                                  action:@selector(addButtonClick)];
    self.navigationItem.rightBarButtonItem = addButton;
    [addButton release];
    
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
