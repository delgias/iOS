//
//  ViewController.h
//  DatabaseAssignment
//
//  Created by Delgias on 11/13/13.
//  Copyright (c) 2013 Delgias. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    
    
}


@property (nonatomic, retain) IBOutlet UITableView* tView;


@end
