//
//  addButtonViewController.h
//  DatabaseAssignment
//
//  Created by Delgias on 11/13/13.
//  Copyright (c) 2013 Delgias. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ContactModel.h"

@protocol RefreshTable

-(void) tableChange;

@end

@interface addButtonViewController : UIViewController


@property (nonatomic, retain) IBOutlet UITextField *textFirstName;
@property (nonatomic, retain) IBOutlet UITextField *textLastName;
@property (nonatomic, retain) IBOutlet UITextField *textEmail;
@property (nonatomic, retain) IBOutlet UITextField *textPhone;
@property (nonatomic, assign) id<RefreshTable> updateView;
@property (nonatomic, retain) IBOutlet UIButton *deleteButton;

@property (nonatomic, retain) ContactModel* cm;
@property (nonatomic, assign) NSInteger indexFromVC;
@property BOOL addClicked;
@property BOOL flag;

-(IBAction)Save:(id)sender;
-(IBAction)delete:(id)sender;
-(IBAction)moveKeyboard:(id)sender;



@end
