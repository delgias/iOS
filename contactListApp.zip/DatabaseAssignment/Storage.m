//
//  Storage.m
//  DatabaseAssignment
//
//  Created by Delgias on 11/13/13.
//  Copyright (c) 2013 Delgias. All rights reserved.
//

#import "Storage.h"
#import "ContactModel.h"
#import "sqlite3.h"

static Storage *Instance = nil;

@implementation Storage
{
    sqlite3* db;
}

@synthesize contactArray = _contactArray;
@synthesize tempArray = _tempArray;
@synthesize value = _value;


+(Storage *) shared
{

    if (Instance == nil) {
        Instance = [[Storage alloc]init];
        [Instance openDB];
        [Instance getData];
        
    }
    return Instance;
}

-(void) setIndexValue:(NSInteger) iValue
{
    _value = &iValue;
    
    NSLog(@"Valu is:  %i", iValue);
    
}

-(void) createTable
{
    
    char *err;
    NSString* createString = @"CREATE TABLE IF NOT EXISTS contacts ("
              @"firstName Varchar(50),"
              @"lastName Varchar(50),"
              @"phone Varchar(20) DEFAULT NULL,"
              @"email Varchar(40),"
              @"ID integer PRIMARY KEY DEFAULT 0)";
    
    
    if (sqlite3_exec(db, [createString UTF8String], NULL, NULL, &err)
        != SQLITE_OK) {
        sqlite3_close(db);
        NSAssert(0, @"Tabled failed to create.");
    }
    
}


-(NSString *) filePath {
    NSArray *paths =
    NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,                                                                                           NSUserDomainMask, YES);
    
    NSString *documentsDir = [paths objectAtIndex:0];
    NSLog(@"Directory:  %@", documentsDir);
    return [documentsDir stringByAppendingPathComponent:@"database.sql"];
}

-(void) openDB {
    
    if (sqlite3_open([[self filePath] UTF8String], &db) != SQLITE_OK ) {
        sqlite3_close(db);
        NSAssert(0, @"Database failed to open.");
    }
    else
    {
        [self createTable];
    }
    
}



-(id) init
{
    self = [super init];
    if (self)
    {
        _contactArray = [[NSMutableArray alloc] init];
    }
    return self;
}


-(void) getData
{
    
    if (_contactArray != nil)
    {
        [_contactArray release];
    }
    
    _contactArray = [[NSMutableArray alloc] init];
    
    NSString *sqlStatement = [NSString stringWithFormat:@"select * from contacts ORDER BY lastName;"];
    
    sqlite3_stmt *sqlLine;
    
    if (sqlite3_prepare_v2(db, [sqlStatement UTF8String], -1, &sqlLine, nil) == SQLITE_OK)
    {
        while (sqlite3_step(sqlLine) == SQLITE_ROW)
        {
            ContactModel *cm = [[ContactModel alloc] init];
            cm.firstName = [NSString stringWithUTF8String:(char*) sqlite3_column_text(sqlLine, 0)];
            cm.lastName = [NSString stringWithUTF8String:(char*) sqlite3_column_text(sqlLine, 1)];
            cm.email = [NSString stringWithUTF8String:(char*) sqlite3_column_text(sqlLine, 2)];
            cm.phone = [NSString stringWithUTF8String:(char*) sqlite3_column_text(sqlLine, 3)];
            cm.ID = sqlite3_column_int(sqlLine, 4);
            
            [self.contactArray addObject:cm];
            [cm release];
        }
        sqlite3_finalize(sqlLine);
    }
    
}

-(void) DeleteContact:(ContactModel*) cm
{
    
     NSString* sqlStatement = [NSString stringWithFormat:@"DELETE FROM contacts WHERE ID = %i;",cm.ID];
    
    char *error;
    if (sqlite3_exec(db, [sqlStatement UTF8String], NULL, NULL, &error ) != SQLITE_OK)
    {
        sqlite3_close(db);
        NSLog(@"Error deleting Contact:  %@", sqlStatement);
    }
    
    [self getData];
    
}


-(void) editAContact:  (ContactModel*) cm : (ContactModel*) newContactData
{
    sqlite3_stmt * sqlUpdate;
    
    const char * sqlCommand= "UPDATE contacts SET firstName = ?, lastName = ?, email = ?, phone = ? Where ID =?";
    
    if(sqlite3_prepare_v2(db, sqlCommand, -1, &sqlUpdate, NULL) != SQLITE_OK)
    {
        NSLog(@"Unable to update contact:  %s", sqlite3_errmsg(db));
    }
    
    sqlite3_bind_text(sqlUpdate, 1, [cm.firstName UTF8String], -1, NULL);
    sqlite3_bind_text(sqlUpdate, 2, [cm.lastName UTF8String], -1, NULL);
    sqlite3_bind_text(sqlUpdate, 3, [cm.email UTF8String], -1, NULL);
    sqlite3_bind_text(sqlUpdate, 4, [cm.phone UTF8String], -1, NULL);
    sqlite3_bind_int(sqlUpdate, 5, newContactData.ID);
    
    
    char* errmsg;
    sqlite3_exec(db, "COMMIT", NULL, NULL, &errmsg);
    
    if(SQLITE_DONE != sqlite3_step(sqlUpdate))
    {
        NSLog(@"Error while updating");
    }
    
    sqlite3_finalize(sqlUpdate);
    
    [self getData];
    
    
    
    
}




-(void) addContact:(ContactModel *)cm
{
    NSString* sql = [NSString stringWithFormat:@"INSERT INTO contacts (firstName,lastName,email,phone) VALUES('%@','%@','%@','%@');",
                     cm.firstName,
                     cm.lastName,
                     cm.email,
                     cm.phone];
    
    char *errorAdding;
    if (sqlite3_exec(db, [sql UTF8String], NULL, NULL, &errorAdding) != SQLITE_OK)
    {
        sqlite3_close(db);
        NSLog(@"Error Adding to db:  %@", sql);
    }
    
    [self getData];
    
}

-(void) createTableNamed:(NSString *) tableName
              withField1:(NSString *) field1
              withField2:(NSString *) field2 {
    
    char *err;
    NSString *sql = [NSString stringWithFormat:
                     @"CREATE TABLE IF NOT EXISTS '%@' ('%@' "
                     "TEXT PRIMARY KEY, '%@' TEXT);",
                     tableName, field1, field2];
    
    if (sqlite3_exec(db, [sql UTF8String], NULL, NULL, &err)
        != SQLITE_OK) {
        sqlite3_close(db);
        NSAssert(0, @"Tabled failed to create.");
    }
}






@end
