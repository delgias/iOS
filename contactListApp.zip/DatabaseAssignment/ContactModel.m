//
//  ContactModel.m
//  DatabaseAssignment
//
//  Created by Deligas on 11/13/13.
//  Copyright (c) 2013 Delgias. All rights reserved.
//

#import "ContactModel.h"

@implementation ContactModel
@synthesize firstName = _firstName;
@synthesize lastName = _lastName;
@synthesize phone = _phone;
@synthesize email = _email;


-(id) initWithFirstName:(NSString*) fn
            AndLastName:(NSString*) ln
               AndEmail:(NSString*) e
               AndPhone:(NSString*) p
{
    _firstName = fn;
    _lastName = ln;
    _email = e;
    _phone = p;
    
    return self;
    
}

-(id)init
{
    self = [super init];
    if(!self)
    {
        return nil;
    }
    
    _firstName = [[NSString alloc] init];
    _lastName = [[NSString alloc] init];
    _email = [[NSString alloc] init];
    _phone = [[NSString alloc] init];
    
    return self;
}


-(void) dealloc
{
    [_firstName release];
    [_lastName release];
    [_phone release];
    [_email release];
    [super dealloc];
}

-(void) LogContact
{
    NSLog(@"First Name:  %@", _firstName);
    NSLog(@"Last Name:  %@", _lastName);
    NSLog(@"Phone:  %@", _phone);
    NSLog(@"Email:  %@", _email);
    
}

@end