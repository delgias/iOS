//
//  Storage.h
//  DatabaseAssignment
//
//  Created by Delgias on 11/13/13.
//  Copyright (c) 2013 Delgias.  All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ContactModel.h"

@interface Storage : NSObject

@property (nonatomic, retain) NSMutableArray* contactArray;
@property (nonatomic, copy) NSArray* tempArray;
@property (nonatomic, assign) NSInteger* value;

+(Storage*) shared;
-(id) init;

-(void) addContact:(ContactModel *)cm;
-(void) DeleteContact:(ContactModel*) cm;
-(void) setIndexValue:(NSInteger) iValue;
-(void) editAContact:  (ContactModel*) cm : (ContactModel*) newContactData;
-(void) getData;
-(void) openDB;
-(void) createTable;



@end
