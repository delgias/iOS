//
//  addButtonViewController.m
//  DatabaseAssignment
//
//  Created by Delgias on 11/13/13.
//  Copyright (c) 2013 Delgias. All rights reserved.
//

#import "addButtonViewController.h"
#import "ContactModel.h"
#import "Storage.h"
#import "ViewController.h"
#import "AppDelegate.h"

@interface addButtonViewController ()
{
    ContactModel* cm;
}

@end

@implementation addButtonViewController

@synthesize textFirstName = _textFirstName;
@synthesize textLastName = _textLastName;
@synthesize textEmail = _textEmail;
@synthesize textPhone = _textPhone;
@synthesize cm = _cm;
@synthesize indexFromVC = _indexFromVC;
@synthesize flag = _flag;
@synthesize addClicked = _addClicked;


-(id) initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    return self;
}

-(IBAction)moveKeyboard:(id)sender
{
    [_textFirstName resignFirstResponder];
    [_textLastName resignFirstResponder];
    [_textPhone resignFirstResponder];
    [_textEmail resignFirstResponder];
}


-(void) alertView:(UIAlertView*) alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0) //  don't delete
    {
    }
    else if (buttonIndex == 1) //  delete
    {
        
        [[Storage shared] DeleteContact:self.cm];
        
        [self.updateView tableChange];
        [self.navigationController popViewControllerAnimated:YES];
        
        
        
    }
    
}



-(IBAction)delete:(id)sender
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Warning" message:@"Would you like to delete this contact?" delegate:self cancelButtonTitle:@"NO" otherButtonTitles:@"YES", nil];
    
    [alert show];
    [alert release];
}



-(IBAction)Save:(id)sender
{
    if (_flag == false) //add
    {
        
        ContactModel* person = [[ContactModel alloc] init];

        person.firstName = _textFirstName.text;
        person.lastName =_textLastName.text;
        person.phone = _textPhone.text;
        person.email = _textEmail.text;

        [[Storage shared] addContact:person];

        [self.updateView tableChange];
        [self.navigationController popViewControllerAnimated:YES];
    }
    else //update
    {
        
        self.cm = [[Storage shared].contactArray objectAtIndex:self.indexFromVC];
        ContactModel* cmm = [[ContactModel alloc] init];
        cmm.firstName = _textFirstName.text;
        cmm.lastName =_textLastName.text;
        cmm.phone = _textPhone.text;
        cmm.email = _textEmail.text;
        
        [[Storage shared] editAContact:  cmm : self.cm];
        
        [self.updateView tableChange];
        [self.navigationController popViewControllerAnimated:YES];
        
    }
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    if (_addClicked == false)
    {
        self.cm = [[Storage shared].contactArray objectAtIndex:self.indexFromVC];

        _textFirstName.text = _cm.firstName;
        _textLastName.text = _cm.lastName;
        _textEmail.text = _cm.email;
        _textPhone.text = _cm.phone;
        
    }
    
    if (_flag == false)
    {
        self.deleteButton.hidden = true;
    }
    
    
    // Do any additional setup after loading the view from its nib.
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
