//
//  ViewController.h
//  InternetBrowsers
//
//  Created by Delgias on 10/10/13.
//  Copyright (c) 2013 Delgias. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UIActionSheetDelegate>
{
    IBOutlet UIWebView *webViewNews;
    IBOutlet UIWebView *webViewSports;
    IBOutlet UIWebView *webViewShopping;
    IBOutlet UIWebView *webViewSocial;
    IBOutlet UIWebView *webViewSchools;
    IBOutlet UIPageControl *pageControl;
}

@property (nonatomic, retain) UIWebView *webViewNews;
@property (nonatomic, retain) UIWebView *webViewSports;
@property (nonatomic, retain) UIWebView *webViewShopping;
@property (nonatomic, retain) UIWebView *webViewSocial;
@property (nonatomic, retain) UIWebView *webViewSchools;

@property (nonatomic, retain) UIPageControl *pageControl;

@property (nonatomic, retain) NSString *buttonClickedName;

-(IBAction)newsButtonClicked:(id)sender;   //  Action for which button the user clicks at the bottom of the app

-(IBAction)sportsButtonClicked:(id)sender;

-(IBAction)shoppingButtonClicked:(id)sender;

-(IBAction)socialButtonClicked:(id)sender;

-(IBAction)schoolsButtonClicked:(id)sender;



@end
