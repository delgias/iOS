//
//  ViewController.m
//  InternetBrowsers
//
//  Created by Delgias on 10/10/13.
//  Copyright (c) 2013 Delgias. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end



@implementation ViewController
@synthesize webViewNews = _webViewNews;
@synthesize webViewSports = _webViewSports;
@synthesize webViewShopping = _webViewShopping;
@synthesize webViewSocial = _webViewSocial;
@synthesize webViewSchools = _WebViewSchools;
@synthesize buttonClickedName = _buttonClickedName;
@synthesize pageControl = _pageControl;

 
 
- (void)viewDidLoad
{
    [_pageControl addTarget:self action:@selector(pageTurning:) forControlEvents:(UIControlEventValueChanged)];
    
    [_webViewNews setHidden:NO];   //  hide most web pages while only allowing 1 to be visible
    [_webViewSports setHidden:YES];
    [_webViewShopping setHidden:YES];
    [_webViewSocial setHidden:YES];
    [_WebViewSchools setHidden:YES];
    
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

-(void) dealloc
{
    [_webViewNews release];  //  release all of our variables
    [_WebViewSchools release];
    [_webViewShopping release];
    [_webViewSocial release];
    [_webViewSports release];
    [_buttonClickedName release];
    [_pageControl release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)newsButtonClicked:(id)sender
{
    _buttonClickedName = @"news"; //  set a string equal to what the user clicks
    
    UIActionSheet* actionSheet =
    [[UIActionSheet alloc] initWithTitle:@"News Menu" delegate:self cancelButtonTitle:@"Ok" destructiveButtonTitle:nil otherButtonTitles:@"CNN", @"Fox News", @"CSpan", nil];   //  create an action sheet that gives the user a few options of news sites to visit
    
    [actionSheet showInView:self.view];
    
}

-(IBAction)sportsButtonClicked:(id)sender
{
    _buttonClickedName = @"sports";
    
    UIActionSheet* actionSheet =
    [[UIActionSheet alloc] initWithTitle:@"Sports Menu" delegate:self cancelButtonTitle:@"Ok" destructiveButtonTitle:nil otherButtonTitles:@"ESPN", @"NFL", @"Arm Wrestling", nil];
    
    [actionSheet showInView:self.view];
    
    
}

-(IBAction)shoppingButtonClicked:(id)sender
{
    _buttonClickedName = @"shopping";
    
    UIActionSheet* actionSheet =
    [[UIActionSheet alloc] initWithTitle:@"Shopping Menu" delegate:self cancelButtonTitle:@"Ok" destructiveButtonTitle:nil otherButtonTitles:@"Buy.com", @"Ebay", nil];
    
    [actionSheet showInView:self.view];
    
}

-(IBAction)socialButtonClicked:(id)sender
{
    _buttonClickedName = @"social";
    
    
    UIActionSheet* actionSheet =
    [[UIActionSheet alloc] initWithTitle:@"Social Menu" delegate:self cancelButtonTitle:@"Ok" destructiveButtonTitle:nil otherButtonTitles:@"Facebook", @"Twitter", nil];
    
    [actionSheet showInView:self.view];
    
    
}

-(void) pageTurning: (UIPageControl *) pageController
{
    NSInteger nextPage = [pageController currentPage];
    
    switch (nextPage)  //  hide all other web pages other than what the user requests to view
    {
        case 0:
            [_webViewNews setHidden:NO];
            [_webViewSports setHidden:YES];
            [_webViewShopping setHidden:YES];
            [_webViewSocial setHidden:YES];
            [_WebViewSchools setHidden:YES];
            
            break;
            
        case 1:
            [_webViewNews setHidden:YES];
            [_webViewSports setHidden:NO];
            [_webViewShopping setHidden:YES];
            [_webViewSocial setHidden:YES];
            [_WebViewSchools setHidden:YES];
            break;
        case 2:
            [_webViewNews setHidden:YES];
            [_webViewSports setHidden:YES];
            [_webViewShopping setHidden:NO];
            [_webViewSocial setHidden:YES];
            [_WebViewSchools setHidden:YES];
            break;
        case 3:
             [_webViewNews setHidden:YES];
             [_webViewSports setHidden:YES];
             [_webViewShopping setHidden:YES];
             [_webViewSocial setHidden:NO];
             [_WebViewSchools setHidden:YES];
            break;
        case 4:
             [_webViewNews setHidden:YES];
             [_webViewSports setHidden:YES];
             [_webViewShopping setHidden:YES];
             [_webViewSocial setHidden:YES];
             [_WebViewSchools setHidden:NO];
            break;
            
        default:
            break;
    }
    
}


-(IBAction)schoolsButtonClicked:(id)sender
{
    _buttonClickedName = @"schools";
    
    UIActionSheet* actionSheet =
    [[UIActionSheet alloc] initWithTitle:@"Schools Menu" delegate:self cancelButtonTitle:@"Ok" destructiveButtonTitle:nil otherButtonTitles:@"Pitt", @"UPJ", @"UPG", @"Penn State", @"IUP", @"Penn Highlands", nil];
    
    [actionSheet showInView:self.view];
    
}

-(void) actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{

    NSString*btnString = [actionSheet buttonTitleAtIndex:buttonIndex];

    if ([_buttonClickedName isEqualToString:@"news"])  //  first if determines category that the user clicked
    {
        if ([btnString isEqualToString:@"CNN"])  //  second if checks what site the user wishes to visit
        {
            NSURL *urlNews = [NSURL URLWithString:@"http://www.cnn.com"];
            NSURLRequest *reqNews = [NSURLRequest requestWithURL:urlNews];
            [_webViewNews loadRequest:reqNews];
        }
        else if ([btnString isEqualToString:@"Fox News"])
        {
            NSURL *url = [NSURL URLWithString:@"http://www.foxnews.com"];
            NSURLRequest *req = [NSURLRequest requestWithURL:url];
            [_webViewNews loadRequest:req];
        }
        else if ([btnString isEqualToString:@"CSpan"])
        {
            NSURL *url = [NSURL URLWithString:@"http://www.cspan.com"];
            NSURLRequest *req = [NSURLRequest requestWithURL:url];
            [_webViewNews loadRequest:req];
        }
    }
    else if ([_buttonClickedName isEqualToString:@"sports"])
    {
    
        if ([btnString isEqualToString:@"ESPN"])
        {
            NSURL *urlNews = [NSURL URLWithString:@"http://www.espn.com"];
            NSURLRequest *reqNews = [NSURLRequest requestWithURL:urlNews];
            [_webViewSports loadRequest:reqNews];
        }
        else if ([btnString isEqualToString:@"NFL"])
        {
            NSURL *url = [NSURL URLWithString:@"http://www.nfl.com"];
            NSURLRequest *req = [NSURLRequest requestWithURL:url];
            [_webViewSports loadRequest:req];
        }
        else if ([btnString isEqualToString:@"Arm Wrestling"])
        {
            NSURL *url = [NSURL URLWithString:@"http://www.armwrestling.com/"];
            NSURLRequest *req = [NSURLRequest requestWithURL:url];
            [_webViewSports loadRequest:req];
        }
    }

    else if ([_buttonClickedName isEqualToString:@"shopping"])
    {
    
        if ([btnString isEqualToString:@"Buy.com"])
        {
            NSURL *urlNews = [NSURL URLWithString:@"http://www.buy.com"];
            NSURLRequest *reqNews = [NSURLRequest requestWithURL:urlNews];
            [_webViewShopping loadRequest:reqNews];
        }
        else if ([btnString isEqualToString:@"Ebay"])
        {
            NSURL *url = [NSURL URLWithString:@"http://www.ebay.com"];
            NSURLRequest *req = [NSURLRequest requestWithURL:url];
            [_webViewShopping loadRequest:req];
        }
    }
    else if ([_buttonClickedName isEqualToString:@"social"])
    {
        
        if ([btnString isEqualToString:@"Facebook"])
        {
            NSURL *urlNews = [NSURL URLWithString:@"http://www.facebook.com"];
            NSURLRequest *reqNews = [NSURLRequest requestWithURL:urlNews];
            [_webViewSocial loadRequest:reqNews];
        }
        else if ([btnString isEqualToString:@"Twitter"])
        {
            NSURL *url = [NSURL URLWithString:@"http://www.twitter.com"];
            NSURLRequest *req = [NSURLRequest requestWithURL:url];
            [_webViewSocial loadRequest:req];
        }
    }
    
    else if ([_buttonClickedName isEqualToString:@"schools"])
    {
        
        if ([btnString isEqualToString:@"Pitt"])
        {
            NSURL *urlNews = [NSURL URLWithString:@"http://www.pitt.edu"];
            NSURLRequest *reqNews = [NSURLRequest requestWithURL:urlNews];
            [_WebViewSchools loadRequest:reqNews];
        }
        else if ([btnString isEqualToString:@"UPJ"])
        {
            NSURL *url = [NSURL URLWithString:@"http://www.upj.pitt.edu"];
            NSURLRequest *req = [NSURLRequest requestWithURL:url];
            [_WebViewSchools loadRequest:req];
        }
        else if ([btnString isEqualToString:@"UPG"])
        {
            NSURL *url = [NSURL URLWithString:@"http://www.upg.pitt.edu"];
            NSURLRequest *req = [NSURLRequest requestWithURL:url];
            [_WebViewSchools loadRequest:req];
        }
        else if ([btnString isEqualToString:@"Penn State"])
        {
            NSURL *url = [NSURL URLWithString:@"http://www.psu.edu"];
            NSURLRequest *req = [NSURLRequest requestWithURL:url];
            [_WebViewSchools loadRequest:req];
        }
        else if ([btnString isEqualToString:@"IUP"])
        {
            NSURL *url = [NSURL URLWithString:@"http://www.iup.edu"];
            NSURLRequest *req = [NSURLRequest requestWithURL:url];
            [_WebViewSchools loadRequest:req];
        }
        else if ([btnString isEqualToString:@"Penn Highlands"])
        {
            NSURL *url = [NSURL URLWithString:@"http://www.pennhighlands.edu"];
            NSURLRequest *req = [NSURLRequest requestWithURL:url];
            [_WebViewSchools loadRequest:req];
        }
    }


}


@end
